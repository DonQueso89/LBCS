def test_me():
    assert True


def test_fail():
    assert False
